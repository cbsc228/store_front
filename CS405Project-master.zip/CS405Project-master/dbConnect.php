<?php
$connect = new PDO("mysql:host=localhost;dbname=CS405Project", "memu225", "Angrysalad592");
?>
