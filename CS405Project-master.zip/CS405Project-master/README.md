# CS405Project
E-commerce web store project

<h3>Notes</h3>
All personalization of db connection can be done from dbConnect.php
